<?php
/**
 * Nuclear Engagement plugin bootstrap file.
 *
 * Provides plugin metadata and prevents direct access.
 *
 * @package NuclearEngagement
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
} // Silence is golden
