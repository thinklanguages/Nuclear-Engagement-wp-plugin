<?php
/**
 * File: modules/toc/loader.php
 *
 * Loads the Nuclen TOC sub-module.
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

/* ------------------------------------------------------------------ */
/*  Local constants (prefixed, module-scoped)                         */
/* ------------------------------------------------------------------ */
define( 'NUCLEN_TOC_DIR',       __DIR__ . '/' );
define( 'NUCLEN_TOC_URL',       plugin_dir_url( __FILE__ ) );

/* ------------------------------------------------------------------ */
/*  Includes                                                          */
/* ------------------------------------------------------------------ */
require_once NUCLEN_TOC_DIR . 'includes/polyfills.php';
require_once NUCLEN_TOC_DIR . 'includes/class-nuclen-toc-utils.php';
require_once NUCLEN_TOC_DIR . 'includes/class-nuclen-toc-render.php';
require_once NUCLEN_TOC_DIR . 'includes/class-nuclen-toc-admin.php';

/* ------------------------------------------------------------------ */
/*  Spin-up                                                            */
/* ------------------------------------------------------------------ */
add_action( 'plugins_loaded', static function () {
	new Nuclen_TOC_Render();   // public hooks (shortcode, filters, assets)
	if ( is_admin() ) {
		new Nuclen_TOC_Admin();    // settings page
	}
} );
