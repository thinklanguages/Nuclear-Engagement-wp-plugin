<?php
declare(strict_types=1);
if ( ! defined( 'ABSPATH' ) ) {
	exit;
} // Silence is golden
