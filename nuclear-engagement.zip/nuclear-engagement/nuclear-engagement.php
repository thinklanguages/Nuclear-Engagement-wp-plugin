<?php
/**
 * Plugin Name:       Nuclear Engagement
 * Plugin URI:        https://www.nuclearengagement.com
 * Description:       Bulk generate engaging content for your blog posts with AI in one click.
 * Version:           1.1
 * Author:            Stefano Lodola
 * Requires at least: 6.1
 * Tested up to:      6.8
 * Requires PHP:      7.4
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       nuclear-engagement
 * Domain Path:       /
 *
 * @package    Nuclear_Engagement
 * @since      1.0.0
 */

declare(strict_types=1);

// If this file is called directly, abort.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Define plugin constants.
define( 'NUCLEN_PLUGIN_FILE', __FILE__ );

// Include the main plugin class.
require_once __DIR__ . '/bootstrap.php';
